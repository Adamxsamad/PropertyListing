// validation.js
const { body } = require('express-validator');

/**
 * Validation rules for property-related requests.
 * Ensures required fields are provided and validates them against specific criteria.
 */
const validateProperty = [
  body("title").notEmpty().withMessage("Title is required"),
  body("location").notEmpty().withMessage("Location is required"),
  body("price").isFloat({ min: 0 }).withMessage("Price must be a non-negative number"),
  body("description").notEmpty().withMessage("Description is required"),
  body("propertyType").trim().toLowerCase().isIn(['apartment', 'penthouse', 'house', 'villa', 'cabin']).withMessage('Invalid property type'),
  body("address").optional().notEmpty().withMessage("Address is required if provided"),
];

/**
 * Validation rules for user registration requests.
 * Checks the presence and formatting of user registration inputs.
 */
const registerValidation = [
  body("username").notEmpty().withMessage("Username is required"),
  body("password").isLength({ min: 6 }).withMessage("Password must be at least 6 characters long"),
  body("email").isEmail().withMessage("Invalid email format"),
  body("contact_number").notEmpty().withMessage("Contact number is required"),
  body("user_type").notEmpty().withMessage("User type is required"),
];

/**
 * Validation rules for user login requests.
 * Verifies that username and password fields are not empty.
 */
const loginValidation = [
  body("username").notEmpty().withMessage("Username is required"),
  body("password").notEmpty().withMessage("Password is required"),
];

// Exports the validation arrays to be used in routes across the application.
module.exports = {
  validateProperty,
  registerValidation,
  loginValidation,
};

const express = require("express");
const router = express.Router();
const { query } = require("../database");
const jwt = require("jsonwebtoken");
const { authenticateJWT } = require("../middleware");
const multer = require("multer");
const upload = require("../multerConfig");
const userController = require('../controllers/userController');

// Route to retrieve user profile information
router.get('/profile/:userId', authenticateJWT, userController.getUserProfile);

// Route to update user profile information
router.put(
  '/profile/:userId',
  authenticateJWT,
  upload.single("profile_picture"),
  userController.updateUserProfile
);

router.post('/favorites/:propertyId', authenticateJWT, userController.addFavoriteProperty);
router.get('/favorites', authenticateJWT, userController.getFavoriteProperties);

module.exports = router;

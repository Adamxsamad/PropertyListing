const express = require("express");
const { query } = require("../database");
const multer = require("multer");
const { body, validationResult, check } = require("express-validator");
const jwt = require("jsonwebtoken");
const {authenticateJWT,isAdmin,} = require("../middleware");
const { validateProperty } = require('../validation');
const router = express.Router();
const upload = require("../multerConfig");
const propertyController = require("../controllers/propertyController");
const userController = require("../controllers/userController")

// JWT secret key
const jwtSecretKey = process.env.JWT_SECRET_KEY;

// Endpoint to list a new property
router.post('/', authenticateJWT, isAdmin, validateProperty, propertyController.createProperty);

// Endpoint to retrieve all properties
router.get('/list', authenticateJWT, propertyController.getProperties);

// Endpoint to update a property
router.put('/update/:propertyId', authenticateJWT, validateProperty, userController.checkOwnership, isAdmin, propertyController.updateProperty);

// Endpoint to delete a property
router.delete('/delete/:propertyId', authenticateJWT, userController.checkOwnership, isAdmin, propertyController.deleteProperty);

const uploadFields = [
  { name: "singleImage", maxCount: 1 },
  { name: "multipleImages", maxCount: 5 },
];

// Endpoint to upload images for a property
router.post(
  '/upload/:propertyId',
  upload.fields(uploadFields),
  authenticateJWT,
  isAdmin,
  userController.checkOwnership,
  propertyController.uploadPropertyImages
);

/// Endpoint to retrieve images for a property, optionally including their IDs
router.get('/:propertyId/images', authenticateJWT, propertyController.getPropertyImages);

// Endpoint to update an image for a property
router.put(
  '/:propertyId/images/update/:imageId',
  upload.single("image"),
  authenticateJWT,
  userController.checkOwnership,
  isAdmin,
  propertyController.updatePropertyImage
);

// Endpoint to delete an image for a property
router.delete(
  '/:propertyId/images/:imageId',
  authenticateJWT,
  isAdmin,
  userController.checkOwnership,
  propertyController.deletePropertyImage
);

// Endpoint to search for a property
router.get('/search', authenticateJWT, propertyController.searchProperties);


module.exports = router;

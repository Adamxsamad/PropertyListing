const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const { query } = require("../database"); 
const loginController = require('../controllers/loginController');
const { registerValidation, loginValidation } = require('../validation')
const router = express.Router();

// Secret key for JWT
const jwtSecretKey = process.env.JWT_SECRET_KEY;

// Registration endpoint with input validation
router.post('/register', registerValidation, loginController.registerUser);

// Login endpoint
router.post('/login', loginValidation, loginController.loginUser);

module.exports = router;

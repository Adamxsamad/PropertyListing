// app.js
const express = require("express");
const app = express();
const userRoutes = require("./routes/usersRoutes");
const loginRoutes = require("./routes/loginRoutes");
const propertyRoutes = require("./routes/propertyRoutes");
require("dotenv").config();
const { authenticateJWT, validateProperty } = require("./middleware");

/**
 * Test endpoint to confirm the server is running.
 */
app.get("/test", (req, res) => {
  res.send("Test route is working");
});

/**
 * Middleware to parse JSON body in incoming requests.
 */
app.use(express.json());

/**
 * Route handlers for different parts of the application.
 */
// Routes for user-related operations (profile management, user-specific actions).
app.use("/user", userRoutes);

// Authentication routes (login, registration).
app.use("/api/auth", loginRoutes);

// Property management routes (listing, updating, deleting properties).
app.use("/properties", propertyRoutes);

/**
 * Starts the server on a specified port from environment variables.
 */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

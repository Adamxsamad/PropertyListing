const loginService = require('../services/loginService');
const { validationResult } = require('express-validator');

async function registerUser(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { username, password, passwordRepeat, email, contact_number, user_type } = req.body;

  try {
    const userId = await loginService.registerUser(username, password, passwordRepeat, email, contact_number, user_type);
    res.status(201).json({ message: "User registered successfully", userId: userId });
  } catch (error) {
    console.error("Error registering user:", error);
    res.status(500).json({ message: "Error registering user", error: error.message });
  }
}

async function loginUser(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
  
    const { username, password } = req.body;
  
    try {
      const loginResult = await loginService.loginUser(username, password);
      res.json(loginResult);
    } catch (error) {
      console.error("Error logging in:", error);
      res.status(500).json({ message: "Error logging in", error: error.message });
    }
  }

module.exports = {
  registerUser,
  loginUser
};

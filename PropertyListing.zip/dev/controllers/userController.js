const userService = require('../services/userService');

async function getUserProfile(req, res) {
  const userId = req.user.userId;

  try {
    const userProfile = await userService.getUserProfile(userId);
    if (userProfile) {
      res.json(userProfile);
    } else {
      res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    console.error("Error retrieving user profile:", error);
    res.status(500).json({ message: "Error retrieving user profile", error: error.message });
  }
}

async function updateUserProfile(req, res) {
    const userId = req.user.userId;
    const { username, location, phone_number, email_address } = req.body;
    const profilePictureUrl = req.file ? req.file.path : null;
  
    try {
      await userService.updateUserProfile(userId, username, profilePictureUrl, location, phone_number, email_address);
      res.json({ message: "User profile updated successfully" });
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ message: "Error updating user profile", error: error.message });
    }
  }

  async function addFavoriteProperty(req, res) {
    const userId = req.user.userId;
    const { propertyId } = req.params;
  
    try {
      await userService.addFavoriteProperty(userId, propertyId);
      res.json({ message: "Property added to favorites" });
    } catch (error) {
      console.error("Error adding favorite property:", error);
      res.status(500).json({ message: "Error adding favorite property", error: error.message });
    }
  }
  
  async function getFavoriteProperties(req, res) {
    const userId = req.user.userId;
  
    try {
      const favoriteProperties = await userService.getFavoriteProperties(userId);
      res.json(favoriteProperties);
    } catch (error) {
      console.error("Error retrieving favorite properties:", error);
      res.status(500).json({ message: "Error retrieving favorite properties", error: error.message });
    }
  }

  async function checkOwnership(req, res, next) {
    const { propertyId } = req.params;
    const userId = req.user.userId;
  
    try {
      const isOwner = await userService.isPropertyOwner(propertyId, userId);
  
      if (!isOwner) {
        return res.status(403).json({ message: 'Forbidden: You do not own this property' });
      }
  
      next();
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error checking ownership', error: error.message });
    }
  }

module.exports = {
  getUserProfile,
  updateUserProfile,
  getFavoriteProperties,
  addFavoriteProperty,
  checkOwnership
};

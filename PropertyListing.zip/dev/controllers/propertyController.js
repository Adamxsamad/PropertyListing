const { validationResult } = require("express-validator");
const propertyService = require("../services/propertyService");

 async function createProperty(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { title, location, price, description, propertyType , availabilityStatus ,address } = req.body;
  const userId = req.user.userId; // Get the user ID from the JWT payload

  try {
    const propertyId = await propertyService.addProperty(
      userId,
      title,
      location,
      price,
      description,
      propertyType,
      availabilityStatus,
      address
    );
    res.status(201).json({
      message: "Property listed successfully",
      propertyId: propertyId,
    });
  } catch (error) {
    console.error(`Error listing property: ${error.message}`, error);
    res.status(500).json({
      message: "Error listing property",
      error: error.message,
    });
  }
}

async function getProperties(req, res) {
  try {
    const properties = await propertyService.getAllProperties();
    res.json(properties);
  } catch (error) {
    console.error("Error retrieving properties:", error);
    res.status(500).json({ message: "Error retrieving properties", error: error.message });
  }
}

async function updateProperty(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { propertyId } = req.params;
  const { title, location, price, availabilityStatus, description } = req.body;

  try {
    const result = await propertyService.updateProperty(propertyId, title, location, price, availabilityStatus, description);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Property not found" });
    }

    res.json({ message: "Property updated successfully" });
  } catch (error) {
    console.error("Error updating property:", error);
    res.status(500).json({ message: "Error updating property", error: error.message });
  }
}

async function deleteProperty(req, res) {
  const { propertyId } = req.params;

  try {
    const result = await propertyService.deleteProperty(propertyId);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Property not found" });
    }

    res.json({ message: "Property deleted successfully" });
  } catch (error) {
    console.error("Error deleting property:", error);
    res.status(500).json({ message: "Error deleting property", error: error.message });
  }
}

async function uploadPropertyImages(req, res) {
  const { propertyId } = req.params;
  const singleImageUrl = req.files.singleImage
    ? req.files.singleImage[0].path
    : null;
  const multipleImageUrls = req.files.multipleImages
    ? req.files.multipleImages.map((file) => file.path)
    : [];

  try {
    await propertyService.savePropertyImages(
      propertyId,
      singleImageUrl,
      multipleImageUrls
    );
    res.json({
      message: "Images uploaded successfully",
      singleImageUrl: singleImageUrl,
      multipleImageUrls: multipleImageUrls,
    });
  } catch (error) {
    console.error("Error uploading images:", error);
    res.status(500).json({ message: "Error uploading images", error: error.message });
  }
}

async function getPropertyImages(req, res) {
  const { propertyId } = req.params;
  const includeIds = req.query.includeIds === 'true';

  try {
    const images = await propertyService.getPropertyImages(propertyId, includeIds);
    res.json(images);
  } catch (error) {
    console.error("Error retrieving images:", error);
    res.status(500).json({ message: "Error retrieving images", error: error.message });
  }
}

async function updatePropertyImage(req, res) {
  const { propertyId, imageId } = req.params;
  const imageUrl = req.file.path;

  try {
    const result = await propertyService.updatePropertyImage(imageId, propertyId, imageUrl);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Image or property not found" });
    }
    res.json({ message: "Image updated successfully", imageUrl: imageUrl });
  } catch (error) {
    console.error("Error updating image:", error);
    res.status(500).json({ message: "Error updating image", error: error.message });
  }
}

async function deletePropertyImage(req, res) {
  const { propertyId, imageId } = req.params;

  try {
    const result = await propertyService.deletePropertyImage(imageId, propertyId);
    if (result.deleted) {
      res.json({ message: "Image deleted successfully" });
    } else {
      res.status(404).json({ message: "Image not found" });
    }
  } catch (error) {
    console.error("Error deleting image:", error);
    res.status(500).json({ message: "Error deleting image", error: error.message });
  }
}

async function searchProperties(req, res) {
  const searchCriteria = req.query;

  try {
    const searchResults = await propertyService.searchProperties(searchCriteria);
    res.json(searchResults);
  } catch (error) {
    console.error("Error searching properties:", error);
    res.status(500).json({ message: "Error searching properties", error: error.message });
  }
}

module.exports = {
  createProperty,
  getProperties,
  updateProperty,
  deleteProperty,
  uploadPropertyImages,
  getPropertyImages,
  updatePropertyImage,
  deletePropertyImage,
  searchProperties
};
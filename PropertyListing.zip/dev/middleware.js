// middleware.js
const jwt = require('jsonwebtoken');
const { query } = require("./database");

/**
 * Middleware to authenticate JWT tokens.
 * This middleware verifies the token provided in the request header.
 * If the token is valid, it sets the user details in the request object for further use.
 * If the token is invalid or expired, it sends an appropriate response.
 */
const authenticateJWT = (req, res, next) => {
    const token = req.headers.authorization;
    if (!token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    const accessToken = token.split(' ')[1];
    jwt.verify(accessToken, process.env.JWT_SECRET_KEY, (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Forbidden. Invalid token.' });
        }

        if (Date.now() >= user.exp * 1000) {
            return res.status(401).json({ message: 'Unauthorized. Token expired.' });
        }

        req.user = user;
        next();
    });
};

/**
 * Middleware to check if the authenticated user is an admin.
 * It denies access if the user does not have an admin role.
 */
const isAdmin = (req, res, next) => {
    if (req.user.userType !== 'admin') {
        return res.status(403).json({ message: 'Forbidden, not an admin' });
    }
    next();
};

module.exports = { authenticateJWT, isAdmin };

const { query } = require("../database");

async function getUserProfile(userId) {
  try {
    const sql = `SELECT username, profile_picture, location, phone_number, email_address, user_type FROM users WHERE user_id = ?`;
    const result = await query(sql, [userId]);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("Error retrieving user profile:", error);
    throw error;
  }
}

async function updateUserProfile(userId, username, profilePictureUrl, location, phone_number, email_address) {
    try {
      const sql = `UPDATE users SET username = ?, profile_picture = ?, location = ?, phone_number = ?, email_address = ? WHERE user_id = ?`;
      await query(sql, [
        username,
        profilePictureUrl,
        location,
        phone_number,
        email_address,
        userId,
      ]);
    } catch (error) {
      console.error("Error updating user profile:", error);
      throw error;
    }
  }

  async function addFavoriteProperty(userId, propertyId) {
    const sql = `INSERT INTO favorites (user_id, property_id) VALUES (?, ?)`;
    await query(sql, [userId, propertyId]);
  }
  
  async function getFavoriteProperties(userId) {
    const sql = `SELECT p.* FROM properties p JOIN favorites f ON p.property_id = f.property_id WHERE f.user_id = ?`;
    const favoriteProperties = await query(sql, [userId]);
    return favoriteProperties;
  }

  async function isPropertyOwner(propertyId, userId) {
    const sql = `SELECT user_id FROM properties WHERE property_id = ?`;
    const result = await query(sql, [propertyId]);
  
    if (result.length === 0) {
      throw new Error('Property not found');
    }
  
    return result[0].user_id === userId;
  }

module.exports = {
  getUserProfile,
  updateUserProfile,
  addFavoriteProperty,
  getFavoriteProperties,
  isPropertyOwner
};

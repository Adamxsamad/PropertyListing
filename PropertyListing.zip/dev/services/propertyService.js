const { query } = require("../database");
const fs = require("fs").promises;

async function addProperty(
  userId,
  title,
  location,
  price,
  description,
  propertyType,
  availabilityStatus,
  address
) {
  try {
    const sql = `INSERT INTO properties (user_id, title, location, price, description, property_type, availability_status, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    const result = await query(sql, [
      userId,
      title,
      location,
      price,
      description,
      propertyType,
      availabilityStatus,
      address || null,
    ]);
    return result.insertId;
  } catch (error) {
    console.error("Error adding property:", error);
    throw error;
  }
}

async function getAllProperties() {
  try {
    const sql = `SELECT * FROM properties`;
    const properties = await query(sql);
    return properties;
  } catch (error) {
    console.error("Error retrieving properties:", error);
    throw error;
  }
}

async function updateProperty(propertyId, title, location, price, description) {
  try {
    const sql = `UPDATE properties SET title = ?, location = ?, price = ?, description = ? WHERE property_id = ?`;
    const result = await query(sql, [
      title,
      location,
      price,
      description,
      propertyId,
    ]);
    return result;
  } catch (error) {
    console.error("Error updating property:", error);
    throw error;
  }
}

async function deleteProperty(id) {
  try {
    const sql = `DELETE FROM properties WHERE property_id = ?`;
    const result = await query(sql, [id]);
    return result;
  } catch (error) {
    console.error("Error deleting property:", error);
    throw error;
  }
}

async function savePropertyImages(
  propertyId,
  singleImageUrl,
  multipleImageUrls
) {
  try {
    if (singleImageUrl) {
      const singleSql = `INSERT INTO property_images (property_id, image_url) VALUES (?, ?)`;
      await query(singleSql, [propertyId, singleImageUrl]);
      return;
    }

    if (multipleImageUrls.length > 0) {
      const values = multipleImageUrls.flatMap((imageUrl) => [
        propertyId,
        imageUrl,
      ]);
      const placeholders = multipleImageUrls.map(() => "(?, ?)").join(", ");
      const multipleSql = `INSERT INTO property_images (property_id, image_url) VALUES ${placeholders}`;
      await query(multipleSql, values);
    }
  } catch (error) {
    console.error("Error saving property images:", error);
    throw error;
  }
}

async function getPropertyImages(propertyId, includeIds) {
  try {
    let sql = `SELECT image_url FROM property_images WHERE property_id = ?`;
    if (includeIds) {
      sql = `SELECT id, image_url FROM property_images WHERE property_id = ?`;
    }
    const images = await query(sql, [propertyId]);
    return includeIds ? images : images.map((row) => row.image_url);
  } catch (error) {
    console.error("Error retrieving property images:", error);
    throw error;
  }
}

async function updatePropertyImage(imageId, propertyId, imageUrl) {
  try {
    const sql = `UPDATE property_images SET image_url = ? WHERE id = ? AND property_id = ?`;
    const result = await query(sql, [imageUrl, imageId, propertyId]);
    return result;
  } catch (error) {
    console.error("Error updating property image:", error);
    throw error;
  }
}

async function deletePropertyImage(imageId, propertyId) {
  try {
    const sqlSelect = `SELECT image_url FROM property_images WHERE id = ? AND property_id = ?`;
    const resultSelect = await query(sqlSelect, [imageId, propertyId]);
    if (resultSelect.length > 0) {
      const imageUrl = resultSelect[0].image_url;

      // Delete the image file asynchronously
      await fs.unlink(imageUrl);

      // Delete the image URL from the property_images table
      const sqlDelete = `DELETE FROM property_images WHERE id = ?`;
      await query(sqlDelete, [imageId]);

      return { deleted: true };
    } else {
      return { deleted: false };
    }
  } catch (error) {
    console.error("Error deleting property image:", error);
    throw error;
  }
}

async function searchProperties(searchCriteria) {
  // SQL query based on the search criteria
  let sql = `SELECT * FROM properties WHERE 1=1`;
  const queryParams = [];

  if (searchCriteria.title) {
    sql += ` AND title LIKE ?`;
    queryParams.push(`%${searchCriteria.title}%`);
  }
  if (searchCriteria.location) {
    sql += ` AND location = ?`;
    queryParams.push(searchCriteria.location);
  }
  if (searchCriteria.minPrice) {
    sql += ` AND price >= ?`;
    queryParams.push(searchCriteria.minPrice);
  }
  if (searchCriteria.type) {
    sql += ` AND type = ?`;
    queryParams.push(searchCriteria.type);
  }
  if (searchCriteria.maxPrice) {
    sql += ` AND price <= ?`;
    queryParams.push(searchCriteria.maxPrice);
  }
  if (searchCriteria.startDate && searchCriteria.endDate) {
    sql += ` AND listing_date BETWEEN ? AND ?`;
    queryParams.push(searchCriteria.startDate, searchCriteria.endDate);
  }

  const properties = await query(sql, queryParams);
  return properties;
}

module.exports = {
  addProperty,
  getAllProperties,
  updateProperty,
  deleteProperty,
  savePropertyImages,
  getPropertyImages,
  updatePropertyImage,
  deletePropertyImage,
  searchProperties,
};

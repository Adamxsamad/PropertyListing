const { query } = require("../database");
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const jwtSecretKey = process.env.JWT_SECRET_KEY;

async function registerUser(username, password, passwordRepeat, email, contact_number, user_type) {
  // Check if user already exists
  const userCheckSql = `SELECT * FROM users WHERE username = ? OR email = ?`;
  const existingUsers = await query(userCheckSql, [username, email]);
  if (existingUsers.length > 0) {
    throw new Error("User already exists");
  }

  if(password !== passwordRepeat){
    throw new Error("Passwords do not match")
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 12);

  // Insert user into database
  const sql = `INSERT INTO users (username, password, email, contact_number, user_type) VALUES (?, ?, ?, ?, ?)`;
  const result = await query(sql, [username, hashedPassword, email, contact_number, user_type]);

  return result.insertId;
}

async function loginUser(username, password) {
    // Check if user exists
    const sql = `SELECT * FROM users WHERE username = ?`;
    const users = await query(sql, [username]);
  
    if (users.length === 0) {
      throw new Error("Invalid credentials");
    }
  
    const user = users[0];
  
    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
  
    if (!isMatch) {
      throw new Error("Invalid credentials");
    }
  
    // Create token with user ID and type
    const tokenPayload = { userId: user.user_id, userType: user.user_type };
    const token = jwt.sign(tokenPayload, jwtSecretKey, { expiresIn: "1h" });
  
    return {
      message: "Logged in successfully",
      token,
      userType: user.user_type,
      userId: user.user_id
    };
  }

module.exports = {
  registerUser,
  loginUser
};
